[![Build Status](https://travis-ci.com/thery/Plouffe.svg?branch=master)](https://travis-ci.com/thery/Plouffe)

# Plouffe
Computing Pi decimal using Plouffe Formula in Coq

## Install
Add the OPAM repository:

    opam repo add coq-released https://coq.inria.fr/opam/released

and run:

    opam install coq-plouffe
